# Import Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# Set plot style
sns.set_style("whitegrid")

# Load Dataset
# Replace with your CSV file path if needed
df = pd.read_csv('student_academic_map_dataset.csv')
df.head()

# Clean column names (very important)
df.columns = df.columns.str.strip()

# Create At_Risk column
df["At_Risk"] = ((df["Current_GPA"] < 2.0) | (df["Failed_Courses"] >= 2)).astype(int)


# Exploratory Data Analysis (EDA)
# Check data info
print(df.info())
print(df.describe())

# Check missing values
print(df.isnull().sum())

# GPA Distribution
plt.figure(figsize=(8,5))
sns.histplot(df["Current_GPA"], bins=10, kde=True)
plt.title("Distribution of Student GPA")
plt.xlabel("GPA")
plt.ylabel("Number of Students")
plt.show()

# GPA Trend by Semester
avg_gpa_per_semester = df.groupby("Semester")["Current_GPA"].mean()
plt.figure(figsize=(8,5))
sns.lineplot(x=avg_gpa_per_semester.index, y=avg_gpa_per_semester.values, marker="o")
plt.title("Average GPA by Semester")
plt.xlabel("Semester")
plt.ylabel("Average GPA")
plt.show()

# Attendance vs GPA
plt.figure(figsize=(8,5))
sns.scatterplot(x="Attendance_Percent", y="Current_GPA", hue="At_Risk", data=df)
plt.title("GPA vs Attendance (Color = At Risk)")
plt.xlabel("Attendance (%)")
plt.ylabel("GPA")
plt.show()

# Average GPA per semester
semester_gpa = df.groupby("Semester")["Current_GPA"].mean().reset_index()

plt.figure(figsize=(8,5))
sns.lineplot(
    data=semester_gpa,
    x="Semester",
    y="Current_GPA",
    marker="o"
)

plt.title("Average GPA Trajectory Across Semesters")
plt.xlabel("Semester")
plt.ylabel("Average GPA")
plt.grid(True)
plt.show()

# Risk Count
risk_counts = df["At_Risk"].value_counts()
plt.figure(figsize=(6,4))
sns.barplot(x=risk_counts.index, y=risk_counts.values)
plt.title("Number of At-Risk vs Not At-Risk Students")
plt.xlabel("At Risk")
plt.ylabel("Number of Records")
plt.show()

# Data Preprocessing
# Features and Target
X = df[["Previous_GPA", "Attendance_Percent", "Credit_Load", "Failed_Courses"]]
y = df["At_Risk"].astype(int)

# Split into train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Logistic Regression Model
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# Make Predictions
y_pred = model.predict(X_test)

# Evaluate Model
accuracy = accuracy_score(y_test, y_pred)
print("Model Accuracy:", accuracy)

cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:\n", cm)

print("Classification Report:\n", classification_report(y_test, y_pred))

# Visualize Confusion Matrix
plt.figure(figsize=(5,4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

# Example: GPA Trend + Risk Count
fig, axes = plt.subplots(1, 2, figsize=(12,5))

# Left: GPA trend by semester
sns.lineplot(x=avg_gpa_per_semester.index, y=avg_gpa_per_semester.values, marker="o", ax=axes[0])
axes[0].set_title("Average GPA by Semester")
axes[0].set_xlabel("Semester")
axes[0].set_ylabel("Average GPA")

# Right: Risk count
sns.barplot(x=risk_counts.index, y=risk_counts.values, ax=axes[1])
axes[1].set_title("Number of At-Risk vs Not At-Risk Students")
axes[1].set_xlabel("At Risk")
axes[1].set_ylabel("Number of Records")

plt.tight_layout()
plt.show()

import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


# Page configuration
st.set_page_config(page_title="Student Academic Map Dashboard", layout="wide")


# Title
st.title("Student Academic Map Dashboard")
st.subheader("ML-Powered Student Performance and Risk Visualization")


# Load dataset
df = pd.read_csv("student_academic_map_dataset.csv")
df.columns = df.columns.str.strip()

# Create At_Risk column
df["At_Risk"] = ((df["Current_GPA"] < 2.0) | (df["Failed_Courses"] >= 2))

# Sidebar filters
st.sidebar.header("Filters")

semester_filter = st.sidebar.selectbox(
    "Select Semester",
    options=["All"] + sorted(df["Semester"].unique().tolist())
)

risk_filter = st.sidebar.selectbox(
    "Select Risk Status",
    options=["All", "At Risk", "Not At Risk"]
)

# Apply filters
filtered_df = df.copy()

if semester_filter != "All":
    filtered_df = filtered_df[filtered_df["Semester"] == semester_filter]

if risk_filter == "At Risk":
    filtered_df = filtered_df[filtered_df["At_Risk"] == True]
elif risk_filter == "Not At Risk":
    filtered_df = filtered_df[filtered_df["At_Risk"] == False]


# Layout columns
col1, col2 = st.columns(2)


# GPA Distribution
with col1:
    st.subheader("Distribution of Student GPA")
    fig, ax = plt.subplots()
    sns.histplot(filtered_df["Current_GPA"], bins=10, kde=True, ax=ax)
    ax.set_xlabel("GPA")
    ax.set_ylabel("Number of Students")
    st.pyplot(fig)


# GPA Trend
with col2:
    st.subheader("Average GPA Trend Across Semesters")
    avg_gpa = filtered_df.groupby("Semester")["Current_GPA"].mean()
    fig, ax = plt.subplots()
    sns.lineplot(x=avg_gpa.index, y=avg_gpa.values, marker="o", ax=ax)
    ax.set_xlabel("Semester")
    ax.set_ylabel("Average GPA")
    st.pyplot(fig)


# Mini Dashboard – Risk Count
st.subheader("Mini Dashboard: Academic Performance and Risk Overview")

col3, col4 = st.columns(2)

with col3:
    st.write("At-Risk vs Not-At-Risk Students")
    risk_counts = filtered_df["At_Risk"].value_counts()
    fig, ax = plt.subplots()
    sns.barplot(x=risk_counts.index.astype(str), y=risk_counts.values, ax=ax)
    ax.set_xlabel("At Risk")
    ax.set_ylabel("Number of Students")
    st.pyplot(fig)

with col4:
    st.write("GPA vs Attendance by Risk Status")
    fig, ax = plt.subplots()
    sns.scatterplot(
        data=filtered_df,
        x="Attendance_Percent",
        y="Current_GPA",
        hue="At_Risk",
        ax=ax
    )
    ax.set_xlabel("Attendance (%)")
    ax.set_ylabel("GPA")
    st.pyplot(fig)


# Footer
st.markdown("---")
st.markdown("**Student Academic Map Project | Data Science Mini Dashboard**")
